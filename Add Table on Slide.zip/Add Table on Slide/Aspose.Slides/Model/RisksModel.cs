﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aspose.Slides.Model
{
    class RisksModel
    {

        public string RiskName { get; set; }
        public string PlannedMitigation { get; set; }
    }
}
